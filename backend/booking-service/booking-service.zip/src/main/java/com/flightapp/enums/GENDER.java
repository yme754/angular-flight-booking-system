package com.flightapp.enums;

public enum GENDER {
	MALE, FEMALE, OTHER
}
