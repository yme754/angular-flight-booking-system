package com.flightapp.enums;

public enum MEAL_PREFERENCE {
	VEG, NON_VEG
}
