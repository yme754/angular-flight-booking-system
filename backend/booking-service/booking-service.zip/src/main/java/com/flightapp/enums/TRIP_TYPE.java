package com.flightapp.enums;

public enum TRIP_TYPE {
	ONE_WAY, ROUND_TRIP
}
