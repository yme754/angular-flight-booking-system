package com.flightapp.entity;

public enum ERole {
	ROLE_USER,
	ROLE_ADMIN
}
