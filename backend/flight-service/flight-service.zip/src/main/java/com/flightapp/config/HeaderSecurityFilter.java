package com.flightapp.config;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.ReactiveSecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;

import reactor.core.publisher.Mono;

@Service
public class HeaderSecurityFilter implements WebFilter {
    @Value("${flightapp.internal.jwt}")
    private String internalJwt;
    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        String authHeader =  exchange.getRequest().getHeaders().getFirst("Authorization");

        if (authHeader != null && authHeader.equals("Bearer " + internalJwt)) {
            UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken("internal-service", null, List.of(new SimpleGrantedAuthority("ROLE_INTERNAL")));
            return chain.filter(exchange).contextWrite( ReactiveSecurityContextHolder.withAuthentication(auth));
        }

        String rolesHeader = exchange.getRequest().getHeaders().getFirst("X-Auth-Roles");
        if (rolesHeader != null && !rolesHeader.isEmpty()) {
            List<SimpleGrantedAuthority> authorities =
                Arrays.stream(rolesHeader.split(",")).map(SimpleGrantedAuthority::new).toList();
            UsernamePasswordAuthenticationToken auth =
                new UsernamePasswordAuthenticationToken("gateway-user",null,authorities);
            return chain.filter(exchange).contextWrite(ReactiveSecurityContextHolder.withAuthentication(auth));
        }
        return chain.filter(exchange);
    }
}
