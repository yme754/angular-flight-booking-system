package com.flightapp.dto;

import lombok.Data;

@Data
public class SearchRequestDTO {
	private String from;
	private String to;
}