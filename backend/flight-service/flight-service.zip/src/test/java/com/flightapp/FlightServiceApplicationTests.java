package com.flightapp;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@Disabled("Skipping context load check")
class FlightServiceApplicationTests {

    @Test
    void contextLoads() {
    }
}